# CárnicoControl 🏭

Sistema de control de presencia para empresas de limpieza en industrias cárnicas.

---

## 🚀 Cómo publicarlo en internet (Vercel) — paso a paso

### Paso 1 — Crear cuenta en GitHub
1. Ve a [github.com](https://github.com) y regístrate gratis
2. Confirma el correo que te envíen

### Paso 2 — Subir el proyecto a GitHub
1. Haz clic en el botón verde **"New"** (o **"+"** arriba a la derecha → New repository)
2. Nombre del repositorio: `carnico-control`
3. Déjalo en **Public** (necesario para el plan gratuito de Vercel)
4. Haz clic en **"Create repository"**
5. En la página siguiente, haz clic en **"uploading an existing file"**
6. **Arrastra toda la carpeta** `carnico-control` a la zona de subida
7. Haz clic en **"Commit changes"**

### Paso 3 — Publicar con Vercel
1. Ve a [vercel.com](https://vercel.com) y regístrate con tu cuenta de GitHub
2. Haz clic en **"Add New Project"**
3. Selecciona el repositorio `carnico-control`
4. Vercel detecta automáticamente que es un proyecto Vite/React
5. Haz clic en **"Deploy"**
6. En 1-2 minutos tendrás una URL tipo: `carnico-control.vercel.app`

### ✅ ¡Listo!
La URL funciona en móvil, tablet y ordenador.
Cada vez que actualices el código en GitHub, Vercel re-despliega automáticamente.

---

## 💻 Ejecutar en tu ordenador (desarrollo local)

Necesitas tener instalado [Node.js](https://nodejs.org) (versión 18 o superior).

```bash
# 1. Abre una terminal en la carpeta del proyecto
cd carnico-control

# 2. Instala las dependencias
npm install

# 3. Arranca el servidor local
npm run dev

# 4. Abre en el navegador: http://localhost:5173
```

---

## 📁 Estructura del proyecto

```
carnico-control/
├── index.html          ← Página principal
├── package.json        ← Dependencias
├── vite.config.js      ← Configuración del bundler
├── README.md           ← Este archivo
└── src/
    ├── main.jsx        ← Punto de entrada React
    └── App.jsx         ← Toda la aplicación
```

---

## ⚙️ Personalizar empresas, industrias y trabajadores

Abre `src/App.jsx` y edita las secciones al inicio del archivo:

```js
// Cambia los nombres de tus empresas reales
const EMPRESAS = [
  { id: "E1", nombre: "Tu Empresa 1 S.L.", ... },
  { id: "E2", nombre: "Tu Empresa 2 S.L.", ... },
];

// Añade tus industrias cárnicas reales
const INDUSTRIAS = [
  { id: "I1", nombre: "Nombre del matadero", localidad: "Ciudad" },
  ...
];

// Define tus trabajadores reales
const TRABAJADORES = [
  { id: "W01", nombre: "Nombre Apellido", empresaId: "E1", industriaId: "I1", contrato: "RG", ... },
  ...
];
```
