import { useState, useEffect, useCallback } from "react";

// ─── MASTER DATA ─────────────────────────────────────────────────────────────

const EMPRESAS = [
  { id: "E1", nombre: "LimCarnes S.L.",       color: "#6366f1", bg: "#6366f115" },
  { id: "E2", nombre: "ProLimpieza Norte S.L.", color: "#f59e0b", bg: "#f59e0b15" },
];

const INDUSTRIAS = [
  { id: "I1", nombre: "Matadero Ibéricos Ramos",   localidad: "Salamanca" },
  { id: "I2", nombre: "Cárnicas del Norte S.A.",    localidad: "Burgos"    },
  { id: "I3", nombre: "Frigorífico Valdés",          localidad: "León"      },
  { id: "I4", nombre: "Matadero Cooperativa Agraria", localidad: "Zamora"   },
];

// contrato: "RG" = Régimen General, "ETT" = Empresa de Trabajo Temporal
const TRABAJADORES = [
  { id: "W01", nombre: "Ana García",       empresaId: "E1", industriaId: "I1", contrato: "RG",  avatar: "AG", rol: "Limpiadora"    },
  { id: "W02", nombre: "Luis Martínez",    empresaId: "E1", industriaId: "I1", contrato: "ETT", avatar: "LM", rol: "Limpiador"     },
  { id: "W03", nombre: "Sara López",       empresaId: "E1", industriaId: "I2", contrato: "RG",  avatar: "SL", rol: "Supervisora"   },
  { id: "W04", nombre: "Carlos Ruiz",      empresaId: "E1", industriaId: "I2", contrato: "ETT", avatar: "CR", rol: "Limpiador"     },
  { id: "W05", nombre: "Marta Blanco",     empresaId: "E1", industriaId: "I3", contrato: "ETT", avatar: "MB", rol: "Limpiadora"    },
  { id: "W06", nombre: "Pedro Jiménez",    empresaId: "E2", industriaId: "I2", contrato: "RG",  avatar: "PJ", rol: "Encargado"     },
  { id: "W07", nombre: "Rosa Fernández",   empresaId: "E2", industriaId: "I3", contrato: "RG",  avatar: "RF", rol: "Limpiadora"    },
  { id: "W08", nombre: "David Moreno",     empresaId: "E2", industriaId: "I3", contrato: "ETT", avatar: "DM", rol: "Limpiador"     },
  { id: "W09", nombre: "Elena Castro",     empresaId: "E2", industriaId: "I4", contrato: "RG",  avatar: "EC", rol: "Supervisora"   },
  { id: "W10", nombre: "Iván Torres",      empresaId: "E2", industriaId: "I4", contrato: "ETT", avatar: "IT", rol: "Limpiador"     },
];

const AVATAR_COLORS = [
  "#6366f1","#8b5cf6","#ec4899","#f59e0b","#14b8a6",
  "#3b82f6","#22c55e","#ef4444","#a855f7","#f97316",
];

// ─── SEED HISTORY ─────────────────────────────────────────────────────────────
const seedRecords = () => {
  const r = [];
  const DAY = 86_400_000;
  const now = Date.now();
  // First 6 workers get 3 days of history
  TRABAJADORES.slice(0, 6).forEach((w, wi) => {
    for (let d = 3; d >= 1; d--) {
      const base = now - d * DAY;
      const midnight = base - (base % DAY);
      const inT  = midnight + (6.5 + Math.random() * 1.5) * 3_600_000;
      const outT = inT + (6 + Math.random() * 2) * 3_600_000;
      r.push({ id: `seed-${wi}-${d}-in`,  trabajadorId: w.id, tipo: "entrada", ts: inT  });
      r.push({ id: `seed-${wi}-${d}-out`, trabajadorId: w.id, tipo: "salida",  ts: outT });
    }
  });
  return r;
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const fmtClock = d => d.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
const fmtDate  = d => d.toLocaleDateString("es-ES",  { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
const fmtShort = ts => new Date(ts).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
const fmtDay   = ts => new Date(ts).toLocaleDateString("es-ES", { weekday: "short", day: "2-digit", month: "short" });
const fmtDayShort = ts => new Date(ts).toLocaleDateString("es-ES", { day: "2-digit", month: "short" });
const todayStart = () => { const d = new Date(); d.setHours(0,0,0,0); return d.getTime(); };

const STATUS_META = {
  active: { label: "Trabajando", dot: "#22c55e", badge: "#22c55e18", text: "#22c55e" },
  out:    { label: "Salida hoy", dot: "#f59e0b", badge: "#f59e0b18", text: "#f59e0b" },
  off:    { label: "Sin fichar", dot: "#475569",  badge: "#47556918", text: "#64748b" },
};

const CONTRATO_META = {
  RG:  { label: "Rég. General", bg: "#6366f118", text: "#818cf8" },
  ETT: { label: "ETT",          bg: "#f59e0b18", text: "#fbbf24" },
};

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [now,      setNow]      = useState(new Date());
  const [records,  setRecords]  = useState(seedRecords);
  const [tab,      setTab]      = useState("panel");   // panel | historial | resumen | admin
  const [toast,    setToast]    = useState(null);

  // Filters
  const [fEmpresa,   setFEmpresa]   = useState("all");
  const [fIndustria, setFIndustria] = useState("all");
  const [fContrato,  setFContrato]  = useState("all");

  // Admin modal
  const [adminModal, setAdminModal] = useState(null); // null | { mode:"add"|"edit", data }
  const [adminForm,  setAdminForm]  = useState({});
  const [trabajadores, setTrabajadores] = useState(TRABAJADORES);

  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 3000); return () => clearTimeout(t); }, [toast]);

  // ─── derived ───────────────────────────────────────────────────────────────
  const statusOf = useCallback((wid) => {
    const ts = todayStart();
    const todayRecs = records.filter(r => r.trabajadorId === wid && r.ts >= ts).sort((a,b) => a.ts - b.ts);
    if (!todayRecs.length) return "off";
    return todayRecs[todayRecs.length - 1].tipo === "entrada" ? "active" : "out";
  }, [records]);

  const lastEntrada = useCallback((wid) => {
    const ts = todayStart();
    return records.filter(r => r.trabajadorId === wid && r.tipo === "entrada" && r.ts >= ts)
                  .sort((a,b) => b.ts - a.ts)[0];
  }, [records]);

  const horasHoy = useCallback((wid) => {
    const ts = todayStart();
    const recs = records.filter(r => r.trabajadorId === wid && r.ts >= ts).sort((a,b) => a.ts - b.ts);
    let total = 0;
    for (let i = 0; i + 1 < recs.length; i += 2) {
      if (recs[i].tipo === "entrada" && recs[i+1]?.tipo === "salida") total += recs[i+1].ts - recs[i].ts;
    }
    if (statusOf(wid) === "active") { const e = lastEntrada(wid); if (e) total += Date.now() - e.ts; }
    const h = Math.floor(total / 3_600_000);
    const m = Math.floor((total % 3_600_000) / 60_000);
    return `${h}h ${String(m).padStart(2,"0")}m`;
  }, [records, statusOf, lastEntrada]);

  // ─── punch ─────────────────────────────────────────────────────────────────
  const punch = (wid) => {
    const status = statusOf(wid);
    const tipo = status === "active" ? "salida" : "entrada";
    setRecords(prev => [...prev, { id: `r-${Date.now()}-${wid}`, trabajadorId: wid, tipo, ts: Date.now() }]);
    const w = trabajadores.find(w => w.id === wid);
    setToast({ nombre: w.nombre, tipo });
  };

  // ─── filtered workers for panel ────────────────────────────────────────────
  const filteredW = trabajadores.filter(w =>
    (fEmpresa   === "all" || w.empresaId   === fEmpresa)   &&
    (fIndustria === "all" || w.industriaId === fIndustria) &&
    (fContrato  === "all" || w.contrato    === fContrato)
  );

  // ─── historial rows ────────────────────────────────────────────────────────
  const histRows = [...records]
    .filter(r => {
      const w = trabajadores.find(x => x.id === r.trabajadorId);
      if (!w) return false;
      return (fEmpresa   === "all" || w.empresaId   === fEmpresa)   &&
             (fIndustria === "all" || w.industriaId === fIndustria) &&
             (fContrato  === "all" || w.contrato    === fContrato);
    })
    .sort((a,b) => b.ts - a.ts)
    .slice(0, 100);

  // ─── resumen: horas por trabajador últimos 7 días ──────────────────────────
  const resumenData = trabajadores
    .filter(w =>
      (fEmpresa   === "all" || w.empresaId   === fEmpresa)   &&
      (fIndustria === "all" || w.industriaId === fIndustria) &&
      (fContrato  === "all" || w.contrato    === fContrato)
    )
    .map(w => {
      const days = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(); d.setDate(d.getDate() - (6 - i));
        const start = new Date(d).setHours(0,0,0,0);
        const end   = start + 86_400_000;
        const recs  = records.filter(r => r.trabajadorId === w.id && r.ts >= start && r.ts < end).sort((a,b) => a.ts - b.ts);
        let total = 0;
        for (let k = 0; k + 1 < recs.length; k += 2)
          if (recs[k].tipo === "entrada" && recs[k+1]?.tipo === "salida") total += recs[k+1].ts - recs[k].ts;
        return { label: fmtDayShort(start + 3_600_000), h: +(total / 3_600_000).toFixed(1) };
      });
      return { w, days, total: days.reduce((s,d) => s + d.h, 0).toFixed(1) };
    });

  // ─── admin helpers ─────────────────────────────────────────────────────────
  const openAdd = () => {
    setAdminForm({ nombre:"", empresaId:"E1", industriaId:"I1", contrato:"RG", rol:"" });
    setAdminModal({ mode:"add" });
  };
  const openEdit = (w) => { setAdminForm({ ...w }); setAdminModal({ mode:"edit" }); };
  const saveAdmin = () => {
    if (!adminForm.nombre?.trim() || !adminForm.rol?.trim()) return;
    if (adminModal.mode === "add") {
      const id = `W${String(Date.now()).slice(-4)}`;
      const idx = trabajadores.length % AVATAR_COLORS.length;
      const initials = adminForm.nombre.split(" ").map(p => p[0]).join("").slice(0,2).toUpperCase();
      setTrabajadores(prev => [...prev, { ...adminForm, id, avatar: initials, _colorIdx: idx }]);
    } else {
      setTrabajadores(prev => prev.map(w => w.id === adminForm.id ? { ...w, ...adminForm } : w));
    }
    setAdminModal(null);
  };
  const deleteWorker = (wid) => {
    if (!confirm("¿Eliminar este trabajador y sus registros?")) return;
    setTrabajadores(prev => prev.filter(w => w.id !== wid));
    setRecords(prev => prev.filter(r => r.trabajadorId !== wid));
  };

  // ─── color idx helper ──────────────────────────────────────────────────────
  const workerColor = (w) => AVATAR_COLORS[(w._colorIdx ?? TRABAJADORES.findIndex(x=>x.id===w.id)) % AVATAR_COLORS.length];

  // ─── STYLES ────────────────────────────────────────────────────────────────
  const C = {
    bg: "#0d1117", surface: "#161b22", border: "#21262d",
    text: "#e6edf3", muted: "#7d8590", accent1: "#6366f1", accent2: "#f59e0b",
  };

  const css = {
    root:    { fontFamily:"'Inter','Segoe UI',system-ui,sans-serif", minHeight:"100vh", background:C.bg, color:C.text, margin:0 },
    header:  { background:C.surface, borderBottom:`1px solid ${C.border}`, padding:"14px 24px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:100 },
    logoWrap:{ display:"flex", alignItems:"center", gap:10 },
    logoBox: { width:38, height:38, borderRadius:10, background:"linear-gradient(135deg,#6366f1,#8b5cf6)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 },
    logoTitle:{ fontSize:17, fontWeight:800, letterSpacing:"-0.4px" },
    logoSub: { fontSize:11, color:C.muted, marginTop:1 },
    clock:   { textAlign:"right" },
    clockT:  { fontSize:20, fontWeight:700, fontVariantNumeric:"tabular-nums", color:C.accent1 },
    clockD:  { fontSize:11, color:C.muted },

    nav:     { background:C.surface, borderBottom:`1px solid ${C.border}`, padding:"0 24px", display:"flex", gap:2 },
    navBtn:  (a) => ({ padding:"12px 18px", border:"none", borderBottom: a ? `2px solid ${C.accent1}` : "2px solid transparent", cursor:"pointer", fontSize:13, fontWeight: a ? 700 : 500, background:"transparent", color: a ? C.text : C.muted, transition:"all .15s" }),

    toolbar: { display:"flex", gap:8, padding:"16px 24px", flexWrap:"wrap", alignItems:"center", borderBottom:`1px solid ${C.border}` },
    select:  { background:C.surface, border:`1px solid ${C.border}`, color:C.text, borderRadius:8, padding:"7px 12px", fontSize:12, cursor:"pointer", outline:"none" },
    label:   { fontSize:11, color:C.muted, fontWeight:600, textTransform:"uppercase", letterSpacing:"0.06em", alignSelf:"center" },

    content: { padding:"20px 24px", maxWidth:1100, margin:"0 auto" },
    sTitle:  { fontSize:11, fontWeight:700, color:C.muted, letterSpacing:"0.1em", textTransform:"uppercase", marginBottom:14 },

    // stat pills
    statRow: { display:"flex", gap:10, flexWrap:"wrap", marginBottom:22 },
    statPill:{ background:C.surface, border:`1px solid ${C.border}`, borderRadius:10, padding:"12px 18px", minWidth:120 },
    statNum: { fontSize:26, fontWeight:800, fontVariantNumeric:"tabular-nums" },
    statLbl: { fontSize:11, color:C.muted, marginTop:2 },

    // worker grid
    grid:    { display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(230px,1fr))", gap:14 },
    card:    (status) => ({ background:C.surface, borderRadius:14, padding:18, border:`1px solid ${status==="active"?"#22c55e33":C.border}`, display:"flex", flexDirection:"column", gap:12 }),
    cardTop: { display:"flex", gap:12, alignItems:"flex-start" },
    avatar:  (col) => ({ width:44, height:44, borderRadius:12, background:col, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:800, fontSize:13, color:"#fff", flexShrink:0, letterSpacing:"0.5px" }),
    wName:   { fontSize:14, fontWeight:700, lineHeight:1.3 },
    wRole:   { fontSize:11, color:C.muted },

    tagRow:  { display:"flex", gap:6, flexWrap:"wrap" },
    tag:     (bg,col) => ({ display:"inline-flex", alignItems:"center", gap:4, background:bg, color:col, borderRadius:6, padding:"2px 8px", fontSize:10, fontWeight:700 }),

    infoRow: { display:"flex", justifyContent:"space-between", alignItems:"center" },
    infoLbl: { fontSize:11, color:C.muted },
    infoVal: { fontSize:14, fontWeight:700, color:C.accent1, fontVariantNumeric:"tabular-nums" },

    punchBtn:(status) => ({
      width:"100%", padding:"9px 0", borderRadius:9, border:"none", cursor:"pointer", fontSize:13, fontWeight:700,
      background: status==="active" ? "linear-gradient(135deg,#ef4444,#dc2626)" : "linear-gradient(135deg,#22c55e,#16a34a)",
      color:"#fff",
    }),

    // historial table
    tableWrap: { background:C.surface, borderRadius:14, border:`1px solid ${C.border}`, overflow:"hidden" },
    tHead:     { display:"grid", gridTemplateColumns:"1.4fr 1fr 1fr 1fr 0.8fr", padding:"10px 18px", background:"#0d1117", color:C.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em" },
    tRow:      (i) => ({ display:"grid", gridTemplateColumns:"1.4fr 1fr 1fr 1fr 0.8fr", padding:"11px 18px", background: i%2===0?C.surface:"#12181f", borderTop:`1px solid ${C.border}`, fontSize:12, alignItems:"center" }),
    tipoBadge: (t) => ({ display:"inline-block", background: t==="entrada"?"#22c55e18":"#ef444418", color: t==="entrada"?"#22c55e":"#f87171", borderRadius:6, padding:"2px 9px", fontSize:10, fontWeight:700, textTransform:"capitalize" }),

    // resumen bars
    sumCard:  { background:C.surface, borderRadius:14, border:`1px solid ${C.border}`, padding:18, marginBottom:12 },
    sumTop:   { display:"flex", alignItems:"center", gap:12, marginBottom:14 },
    sumRight: { marginLeft:"auto", textAlign:"right" },
    barArea:  { display:"flex", gap:4, height:56, alignItems:"flex-end" },
    barCol:   { flex:1, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"flex-end", height:56 },
    barFill:  (h, max) => ({ width:"100%", background: h>0?"linear-gradient(to top,#6366f1,#818cf8)":"#21262d", borderRadius:"3px 3px 0 0", height: max>0?`${Math.max(4, h/max*52)}px`:"4px" }),
    barLbl:   { fontSize:8, color:C.muted, marginTop:4, textAlign:"center", fontVariantNumeric:"tabular-nums" },

    // admin table
    adminTable: { background:C.surface, borderRadius:14, border:`1px solid ${C.border}`, overflow:"hidden" },
    aHead:   { display:"grid", gridTemplateColumns:"1.5fr 1fr 1.2fr 0.8fr 0.8fr 80px", padding:"10px 18px", background:"#0d1117", color:C.muted, fontSize:10, fontWeight:700, textTransform:"uppercase", letterSpacing:"0.07em" },
    aRow:    (i) => ({ display:"grid", gridTemplateColumns:"1.5fr 1fr 1.2fr 0.8fr 0.8fr 80px", padding:"11px 18px", background: i%2===0?C.surface:"#12181f", borderTop:`1px solid ${C.border}`, fontSize:12, alignItems:"center" }),
    addBtn:  { background:C.accent1, color:"#fff", border:"none", borderRadius:9, padding:"8px 18px", fontSize:13, fontWeight:700, cursor:"pointer", marginLeft:"auto" },
    iconBtn: (col) => ({ background:"transparent", border:`1px solid ${col}22`, color:col, borderRadius:7, padding:"4px 10px", fontSize:11, cursor:"pointer", fontWeight:600 }),

    // modal
    overlay: { position:"fixed", inset:0, background:"#00000099", display:"flex", alignItems:"center", justifyContent:"center", zIndex:500, padding:16 },
    modal:   { background:C.surface, borderRadius:16, border:`1px solid ${C.border}`, padding:28, width:"100%", maxWidth:440 },
    mTitle:  { fontSize:16, fontWeight:800, marginBottom:20 },
    mField:  { marginBottom:14 },
    mLabel:  { fontSize:11, fontWeight:700, color:C.muted, display:"block", marginBottom:5, textTransform:"uppercase", letterSpacing:"0.06em" },
    mInput:  { width:"100%", background:"#0d1117", border:`1px solid ${C.border}`, color:C.text, borderRadius:8, padding:"9px 12px", fontSize:13, boxSizing:"border-box", outline:"none" },
    mBtnRow: { display:"flex", gap:10, marginTop:20, justifyContent:"flex-end" },
    mBtnCancel: { background:"transparent", border:`1px solid ${C.border}`, color:C.muted, borderRadius:9, padding:"9px 18px", fontSize:13, cursor:"pointer", fontWeight:600 },
    mBtnSave:   { background:C.accent1, color:"#fff", border:"none", borderRadius:9, padding:"9px 18px", fontSize:13, fontWeight:700, cursor:"pointer" },

    // toast
    toast: { position:"fixed", bottom:22, right:22, background:C.surface, border:`1px solid ${C.accent1}44`, borderRadius:12, padding:"13px 18px", display:"flex", gap:12, alignItems:"center", boxShadow:"0 8px 32px #00000066", zIndex:999, minWidth:240 },
    toastIcon: (tipo) => ({ width:36, height:36, borderRadius:9, background: tipo==="entrada"?"#22c55e18":"#ef444418", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }),
  };

  // ─── empresas lookup ────────────────────────────────────────────────────────
  const empOf = (eid) => EMPRESAS.find(e=>e.id===eid);
  const indOf = (iid) => INDUSTRIAS.find(i=>i.id===iid);

  // ─── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={css.root}>

      {/* HEADER */}
      <div style={css.header}>
        <div style={css.logoWrap}>
          <div style={css.logoBox}>🏭</div>
          <div>
            <div style={css.logoTitle}>CárnicoControl</div>
            <div style={css.logoSub}>Control de presencia · Industrias cárnicas</div>
          </div>
        </div>
        <div style={css.clock}>
          <div style={css.clockT}>{fmtClock(now)}</div>
          <div style={css.clockD}>{fmtDate(now)}</div>
        </div>
      </div>

      {/* NAV */}
      <div style={css.nav}>
        {[["panel","🟢  Panel"],["historial","📋  Historial"],["resumen","📊  Resumen"],["admin","⚙️  Trabajadores"]].map(([id,label])=>(
          <button key={id} style={css.navBtn(tab===id)} onClick={()=>setTab(id)}>{label}</button>
        ))}
      </div>

      {/* TOOLBAR */}
      <div style={css.toolbar}>
        <span style={css.label}>Filtrar por</span>
        <select style={css.select} value={fEmpresa} onChange={e=>setFEmpresa(e.target.value)}>
          <option value="all">Todas las empresas</option>
          {EMPRESAS.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}
        </select>
        <select style={css.select} value={fIndustria} onChange={e=>setFIndustria(e.target.value)}>
          <option value="all">Todas las industrias</option>
          {INDUSTRIAS.map(i=><option key={i.id} value={i.id}>{i.nombre}</option>)}
        </select>
        <select style={css.select} value={fContrato} onChange={e=>setFContrato(e.target.value)}>
          <option value="all">Todos los contratos</option>
          <option value="RG">Régimen General</option>
          <option value="ETT">ETT</option>
        </select>
      </div>

      <div style={css.content}>

        {/* ── PANEL ───────────────────────────────────────────────── */}
        {tab === "panel" && (<>
          {/* stat pills */}
          <div style={css.statRow}>
            {[
              { num: filteredW.filter(w=>statusOf(w.id)==="active").length, lbl:"Trabajando ahora",   col:"#22c55e" },
              { num: filteredW.filter(w=>statusOf(w.id)==="out").length,    lbl:"Con salida hoy",     col:C.accent2 },
              { num: filteredW.filter(w=>statusOf(w.id)==="off").length,    lbl:"Sin fichar",         col:C.muted   },
              { num: filteredW.filter(w=>w.contrato==="ETT").length,        lbl:"Trabajadores ETT",   col:"#fbbf24" },
              { num: filteredW.filter(w=>w.contrato==="RG").length,         lbl:"Rég. General",       col:"#818cf8" },
            ].map((s,i)=>(
              <div key={i} style={css.statPill}>
                <div style={{...css.statNum, color:s.col}}>{s.num}</div>
                <div style={css.statLbl}>{s.lbl}</div>
              </div>
            ))}
          </div>

          {/* cards by empresa */}
          {EMPRESAS.map(emp => {
            const wks = filteredW.filter(w=>w.empresaId===emp.id);
            if (!wks.length) return null;
            return (
              <div key={emp.id} style={{marginBottom:28}}>
                <div style={{display:"flex", alignItems:"center", gap:10, marginBottom:14}}>
                  <div style={{width:4, height:18, borderRadius:2, background:emp.color}} />
                  <p style={{...css.sTitle, margin:0}}>{emp.nombre}</p>
                </div>
                <div style={css.grid}>
                  {wks.map((w) => {
                    const status = statusOf(w.id);
                    const meta   = STATUS_META[status];
                    const cm     = CONTRATO_META[w.contrato];
                    const ind    = indOf(w.industriaId);
                    const entry  = lastEntrada(w.id);
                    const col    = workerColor(w);
                    return (
                      <div key={w.id} style={css.card(status)}>
                        <div style={css.cardTop}>
                          <div style={css.avatar(col)}>{w.avatar}</div>
                          <div style={{flex:1}}>
                            <div style={css.wName}>{w.nombre}</div>
                            <div style={css.wRole}>{w.rol}</div>
                          </div>
                        </div>

                        <div style={css.tagRow}>
                          <span style={css.tag(cm.bg, cm.text)}>{cm.label}</span>
                          <span style={css.tag(emp.bg, emp.color)}>
                            {emp.nombre.length > 16 ? emp.nombre.slice(0,16)+"…" : emp.nombre}
                          </span>
                        </div>

                        <div style={{fontSize:11, color:C.muted, display:"flex", gap:4, alignItems:"center"}}>
                          🏭 {ind?.nombre ?? "—"}
                        </div>

                        <div style={{display:"flex", alignItems:"center", gap:6}}>
                          <span style={{width:7,height:7,borderRadius:"50%",background:meta.dot,flexShrink:0}} />
                          <span style={{fontSize:11, fontWeight:600, color:meta.text}}>{meta.label}</span>
                          {entry && status==="active" && (
                            <span style={{fontSize:11, color:C.muted, marginLeft:"auto"}}>desde {fmtShort(entry.ts)}</span>
                          )}
                        </div>

                        <div style={css.infoRow}>
                          <span style={css.infoLbl}>Horas hoy</span>
                          <span style={css.infoVal}>{horasHoy(w.id)}</span>
                        </div>

                        <button
                          style={css.punchBtn(status)}
                          onClick={() => punch(w.id)}
                          onMouseOver={e=>e.currentTarget.style.opacity=".8"}
                          onMouseOut={e=>e.currentTarget.style.opacity="1"}
                        >
                          {status==="active" ? "⬛  Registrar Salida" : "▶  Registrar Entrada"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </>)}

        {/* ── HISTORIAL ────────────────────────────────────────────── */}
        {tab === "historial" && (<>
          <p style={css.sTitle}>Historial de marcajes ({histRows.length} registros)</p>
          <div style={css.tableWrap}>
            <div style={css.tHead}>
              <span>Trabajador</span><span>Empresa</span><span>Industria</span><span>Fecha / Hora</span><span>Tipo</span>
            </div>
            {histRows.length === 0 && (
              <div style={{padding:32, textAlign:"center", color:C.muted}}>No hay marcajes para los filtros seleccionados.</div>
            )}
            {histRows.map((r,i)=>{
              const w   = trabajadores.find(x=>x.id===r.trabajadorId);
              const emp = empOf(w?.empresaId);
              const ind = indOf(w?.industriaId);
              return (
                <div key={r.id} style={css.tRow(i)}>
                  <span style={{fontWeight:600}}>{w?.nombre ?? "—"}</span>
                  <span style={{color: emp?.color ?? C.muted}}>{emp?.nombre.split(" ")[0] ?? "—"}</span>
                  <span style={{color:C.muted, fontSize:11}}>{ind?.nombre ?? "—"}</span>
                  <span style={{fontVariantNumeric:"tabular-nums"}}>{fmtDay(r.ts)} {fmtShort(r.ts)}</span>
                  <span><span style={css.tipoBadge(r.tipo)}>{r.tipo === "entrada" ? "▲ Entrada" : "▼ Salida"}</span></span>
                </div>
              );
            })}
          </div>
        </>)}

        {/* ── RESUMEN ──────────────────────────────────────────────── */}
        {tab === "resumen" && (<>
          <p style={css.sTitle}>Horas trabajadas · últimos 7 días</p>
          {resumenData.length === 0 && <div style={{color:C.muted}}>Sin trabajadores para los filtros seleccionados.</div>}
          {EMPRESAS.map(emp => {
            const rows = resumenData.filter(d=>d.w.empresaId===emp.id);
            if (!rows.length) return null;
            return (
              <div key={emp.id} style={{marginBottom:28}}>
                <div style={{display:"flex", alignItems:"center", gap:10, marginBottom:12}}>
                  <div style={{width:4, height:18, borderRadius:2, background:emp.color}} />
                  <p style={{...css.sTitle, margin:0}}>{emp.nombre}</p>
                </div>
                {rows.map(({w, days, total}) => {
                  const maxH = Math.max(...days.map(d=>d.h), 8);
                  const cm   = CONTRATO_META[w.contrato];
                  const ind  = indOf(w.industriaId);
                  return (
                    <div key={w.id} style={css.sumCard}>
                      <div style={css.sumTop}>
                        <div style={css.avatar(workerColor(w))}>{w.avatar}</div>
                        <div>
                          <div style={{fontSize:14,fontWeight:700}}>{w.nombre}</div>
                          <div style={{display:"flex",gap:6,marginTop:3}}>
                            <span style={css.tag(cm.bg,cm.text)}>{cm.label}</span>
                            <span style={{fontSize:11,color:C.muted}}>{ind?.nombre}</span>
                          </div>
                        </div>
                        <div style={css.sumRight}>
                          <div style={{fontSize:24,fontWeight:800,color:C.accent1,fontVariantNumeric:"tabular-nums"}}>{total}h</div>
                          <div style={{fontSize:11,color:C.muted}}>semana total</div>
                        </div>
                      </div>
                      <div style={css.barArea}>
                        {days.map(d=>(
                          <div key={d.label} style={css.barCol}>
                            <div style={{fontSize:8,color:C.accent1,marginBottom:2,fontWeight:700}}>{d.h>0?`${d.h}h`:""}</div>
                            <div style={css.barFill(d.h,maxH)} />
                          </div>
                        ))}
                      </div>
                      <div style={{display:"flex",gap:4,marginTop:4}}>
                        {days.map(d=>(
                          <div key={d.label} style={css.barLbl}>{d.label}</div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })}
        </>)}

        {/* ── ADMIN ────────────────────────────────────────────────── */}
        {tab === "admin" && (<>
          <div style={{display:"flex",alignItems:"center",marginBottom:16}}>
            <p style={{...css.sTitle,margin:0}}>Gestión de trabajadores ({filteredW.length})</p>
            <button style={css.addBtn} onClick={openAdd}>+ Añadir trabajador</button>
          </div>
          <div style={css.adminTable}>
            <div style={css.aHead}>
              <span>Nombre</span><span>Empresa</span><span>Industria</span><span>Contrato</span><span>Rol</span><span>Acciones</span>
            </div>
            {filteredW.length === 0 && <div style={{padding:28,textAlign:"center",color:C.muted}}>Sin resultados.</div>}
            {filteredW.map((w,i)=>{
              const emp = empOf(w.empresaId);
              const ind = indOf(w.industriaId);
              const cm  = CONTRATO_META[w.contrato];
              return (
                <div key={w.id} style={css.aRow(i)}>
                  <span style={{fontWeight:700,display:"flex",gap:8,alignItems:"center"}}>
                    <span style={{width:26,height:26,borderRadius:7,background:workerColor(w),display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:"#fff"}}>{w.avatar}</span>
                    {w.nombre}
                  </span>
                  <span style={{color:emp?.color,fontSize:11,fontWeight:600}}>{emp?.nombre.split(" ")[0]}</span>
                  <span style={{color:C.muted,fontSize:11}}>{ind?.localidad}</span>
                  <span><span style={css.tag(cm.bg,cm.text)}>{cm.label}</span></span>
                  <span style={{color:C.muted,fontSize:11}}>{w.rol}</span>
                  <span style={{display:"flex",gap:6}}>
                    <button style={css.iconBtn(C.accent1)} onClick={()=>openEdit(w)}>Editar</button>
                    <button style={css.iconBtn("#ef4444")} onClick={()=>deleteWorker(w.id)}>✕</button>
                  </span>
                </div>
              );
            })}
          </div>
        </>)}

      </div>

      {/* ── ADMIN MODAL ──────────────────────────────────────────────── */}
      {adminModal && (
        <div style={css.overlay} onClick={e=>{ if(e.target===e.currentTarget) setAdminModal(null); }}>
          <div style={css.modal}>
            <div style={css.mTitle}>{adminModal.mode==="add"?"Nuevo trabajador":"Editar trabajador"}</div>

            {[
              { key:"nombre",    label:"Nombre completo", type:"text"  },
              { key:"rol",       label:"Rol / Puesto",    type:"text"  },
            ].map(f=>(
              <div key={f.key} style={css.mField}>
                <label style={css.mLabel}>{f.label}</label>
                <input style={css.mInput} type={f.type} value={adminForm[f.key]||""} onChange={e=>setAdminForm(p=>({...p,[f.key]:e.target.value}))} />
              </div>
            ))}

            <div style={css.mField}>
              <label style={css.mLabel}>Empresa</label>
              <select style={{...css.mInput,cursor:"pointer"}} value={adminForm.empresaId||"E1"} onChange={e=>setAdminForm(p=>({...p,empresaId:e.target.value}))}>
                {EMPRESAS.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}
              </select>
            </div>

            <div style={css.mField}>
              <label style={css.mLabel}>Industria cárnica</label>
              <select style={{...css.mInput,cursor:"pointer"}} value={adminForm.industriaId||"I1"} onChange={e=>setAdminForm(p=>({...p,industriaId:e.target.value}))}>
                {INDUSTRIAS.map(i=><option key={i.id} value={i.id}>{i.nombre} — {i.localidad}</option>)}
              </select>
            </div>

            <div style={css.mField}>
              <label style={css.mLabel}>Tipo de contrato</label>
              <select style={{...css.mInput,cursor:"pointer"}} value={adminForm.contrato||"RG"} onChange={e=>setAdminForm(p=>({...p,contrato:e.target.value}))}>
                <option value="RG">Régimen General</option>
                <option value="ETT">ETT – Empresa de Trabajo Temporal</option>
              </select>
            </div>

            <div style={css.mBtnRow}>
              <button style={css.mBtnCancel} onClick={()=>setAdminModal(null)}>Cancelar</button>
              <button style={css.mBtnSave} onClick={saveAdmin}>
                {adminModal.mode==="add"?"Añadir trabajador":"Guardar cambios"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOAST */}
      {toast && (
        <div style={css.toast}>
          <div style={css.toastIcon(toast.tipo)}>
            {toast.tipo==="entrada"?"▶":"⬛"}
          </div>
          <div>
            <div style={{fontWeight:700,fontSize:14}}>{toast.nombre}</div>
            <div style={{fontSize:12,color:C.muted}}>
              {toast.tipo==="entrada"?"Entrada registrada":"Salida registrada"} · {fmtClock(new Date())}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
